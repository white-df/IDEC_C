#include <stdio.h>

void temp(void) {
    printf("temp\n");
}
