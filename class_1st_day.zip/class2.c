#include <stdio.h>
#include "myheader.h"

// 2차시. 조건문과 반복문

int main(int argc, const char * argv[]) {

    // scanf 사용하기!
    // 콘솔창에서 사용자로부터 값을 입력받을 수 있다.
    int num;
    printf("Ex. 정수를 입력하세요: ");
    scanf("%d", &num);
    printf("%d\n", num);

    // 조건문을 연습해보자

    // 연습 1) 정수형 변수 a가 5보다 크거나 같으면 "BIG"을 출력하고 작으면 "SMALL"을 출력하도록 하자
    int a;
    printf("if_01. 정수를 입력하세요: ");
    scanf("%d", &a);

    if (a >= 5) { printf("BIG\n"); }
    else { printf("SMALL\n"); }

    // 연습 2) 정수형 변수 b가 5보다 크면 "BIG"을 출력하고 작으면 "SMALL"을 출력하되 모두 해당되지 않을 경우 "EQUAL"을 출력하도록 하자
    int b;
    printf("if_02. 정수를 입력하세요: ");
    scanf("%d", &b);

    if (b > 5) { printf("BIG\n"); }
    else if ( b < 5 ) { printf("SMALL\n"); }
    else { printf("EQUAL\n"); }

    // 연습 3) 정수형 변수 c를 2로 나누었을 때 나머지 값이 0이면 "ZERO"를 출력하고 1이면 "ONE"을 출력하도록 하자
    int c;
    printf("if_03. 정수를 입력하세요: ");
    scanf("%d", &c);

    if ( c % 2 == 1 ) { printf("ONE\n"); }
    else { printf("ZERO\n"); }


    // 연습 4) 정수형 변수 d를 2로 나누어 몫 값과 나머지 값을 구했다고 하자.
    // 나머지 값이 0일 때, 몫이 1보다 크거나 같으면 "ZERO BIG"을 출력하고 몫이 1보다 작으면 "ZERO SMALL"을 출력하도록 하자
    // 나머지 값일 1일 때, 몫이 1보다 크거나 같으면 "ONE BIG"을 출력하고 몫이 1보자 작으면 "ONE SMALL"을 출력하도록 하자
    int d;
    printf("if_04. 정수를 입력하세요: ");
    scanf("%d", &d);

    if (d % 2 == 0) {
        if (d / 2 >= 1) { printf("ZERO BIG\n"); }
        else { printf("ZERO SMALL\n"); }
    }
    else {
        if (d / 2 >= 1) { printf("ONE BIG\n"); }
        else { printf("ONE SMALL\n"); }
    }

    // 연습 5) 정수형 변수 e를 2로 나누어 몫 값과 나머지 값을 구했다고 하자.
    // 나머지 값이 0일 때, 몫이 1보다 크거나 같으면 "0 BIG"을 출력하고 몫이 1보다 작으면 "0 SMALL"을 출력하도록 하자
    // 나머지 값일 1일 때, 몫이 1보다 크거나 같으면 "1 BIG"을 출력하고 몫이 1보자 작으면 "1 SMALL"을 출력하도록 하자
    int e;
    printf("if_05. 정수를 입력하세요: ");
    scanf("%d", &e);

    if (e/2 >= 1) { printf("%d BIG\n", e%2); }
    else {printf("%d SMALL\n", e%2); }

    // 연습 6) 정수형 변수 score가 가질 수 있는 값의 범위에 따라 grade를 매기는 코드를 짜보자.
    // grade 채점 기준은 아래와 같다.

    /*
     (100점 기준)
     A+ : 97점 이상         (97 <= score <= 100)
     A0 : 94점 이상 97점 미만 (94 <= score <= 96 )
     A- : 90점 이상 94점 미만 (90 <= score <= 93 )

     B+ : 87점 이상 90점 미만 (87 <= score <= 89 )
     B0 : 84점 이상 87점 미만 (84 <= score <= 86 )
     B- : 80점 이상 84점 미만 (80 <= score <= 83 )

     C+ : 77점 이상 80점 미만 (77 <= score <= 79 )
     C0 : 74점 이상 77점 미만 (74 <= score <= 76 )
     C- : 70점 이상 74점 미만 (70 <= score <= 73 )

     D+ : 67점 이상 70점 미만 (67 <= score <= 69 )
     D0 : 64점 이상 67점 미만 (64 <= score <= 66 )
     D- : 60점 이상 64점 미만 (60 <= score <= 63 )

     F  : 60점 미만         ( 0 <= score <= 59 )
    */
    int score;
    printf("if_06. 점수(score)를 입력하세요: ");
    scanf("%d", &score);

    if ((score < 0) || (score > 100)) { printf("Out of Range\n"); }
    else {
        if (score >= 97) { printf("A+\n"); }
        else if (score >= 94) { printf("A0\n"); }
        else if (score >= 90) { printf("A-\n"); }

        else if (score >= 87) { printf("B+\n"); }
        else if (score >= 84) { printf("B0\n"); }
        else if (score >= 80) { printf("B-\n"); }

        else if (score >= 77) { printf("C+\n"); }
        else if (score >= 74) { printf("C0\n"); }
        else if (score >= 70) { printf("C-\n"); }

        else if (score >= 67) { printf("D+\n"); }
        else if (score >= 64) { printf("D0\n"); }
        else if (score >= 60) { printf("D-\n"); }

        else { printf("F\n"); }
    }


    // 연습 7) 정수형 변수 mathScore와 정수형 변수 engScore는 각각 수학 시험과 영어 시험의 점수라고 가정하자.
    int mathScore, engScore;
    printf("if_07. 수학 점수와 영어 점수를 입력하세요: ");
    scanf("%d %d", &mathScore, &engScore);

    // 연습 7-1) 두 시험의 성적이 모두 80점 이상일 경우 "PASS"를 출력하고 그렇지 않을 경우 "FAIL"을 출력하는 코드를 작성해보자.
    printf("if_07-1. 결과: ");
    if ((mathScore >= 80) && (engScore >= 80)) {
        printf("PASS\n");
    } else {
        printf("FAIL\n");
    }

    // 연수 7-2) 한 과목만 80점 이상일 경우에는 "RETAKE"을 출력하는 조건을 추가하고 두 과목 모두 80점 이상이 아닐 경우에는 "FAIL"을 출력하는 코드를 작성해보자.
    printf("if_07-2. 결과: ");
    if ((mathScore >= 80) && (engScore >= 80)) {
        printf("PASS\n");
    }
    else if ((mathScore >= 80) || (engScore >= 80)) {
        printf("RETAKE\n");
    }
    else {
        printf("FAIL\n");
    }

    // 연습 8) 종수가 상점을 갔다. 해당 상점은 구매액에 따라 서로 다른 할인율을 적용한다. 1만원 이상은 5%, 5만원 이상은 10%, 10만원 이상은 20%의 할인율이 적용된다. 구매액을 나타내는 정수형의 변수를 cash라고 했을 때, 최종 결제액을 출력하는 코드를 작성해보자.
    // Ex) 구매액이 12,000원이면 5% 할인이 적용돼 600원이 할인되어 최종 결제액은 11,400원이다.
    int cash;
    printf("if_08. 구매액을 입력하세요: ");
    scanf("%d", &cash);

    float disc;
    int result;

    if (cash >= 100000) { disc = 0.8; }
    else if (cash >= 50000) { disc = 0.9; }
    else if (cash >= 10000) { disc = 0.95; }
    else { disc = 1.0; }

    result = cash * disc;
    printf("%d\n", result);



    // 반복문 for문을 연습해보자

    // 연습 1) 0부터 9까지 출력해보자
    printf("for_01. 결과\n");
    int f;
    for (f = 0; f < 10; f++) {
        printf("%d ", f);
    }
    printf("\n");

    // 연습 2) for문을 이용해 다음과 같이 "****"을 총 10줄 출력해보자
    /*
     ****
     ****
     ****
     ****
     ****
     ****
     ****
     ****
     ****
     ****
    */
    printf("for_02. 결과\n");
    int g;
    for (g = 0; g < 10; g++) {
        printf("****\n");
    }

    // 연습 3) for문을 이용해 다음과 같이 출력해보자
    /*
     *
     **
     ***
     ****
     *****
     ******
     *******
     ********
     *********
     **********
    */
    printf("for_03. 결과\n");
    int h, i;
    for (h = 1; h <= 10; h++) {
        for (i = 1; i <= h; i++) {
            printf("*");
        }
        printf("\n");
    }

    // 연습 4) for문과 조건문을 이용해 다음과 같이 출력해보자
    /*
     *
     ***
     *****
     *******
     *********
    */
    printf("for_04. 결과\n");
    int j,k;
    for (j=1; j<=10; j++) {
        if (j%2 == 1) {
            for (k=1; k<=j; k++) {
                printf("*");
            }
            printf("\n");
        }
    }

    // 연습 5) for문을 이용해 다음과 같이 출력해보자
    /*
     줄마다 뭔가를 실행시키는 반복문
     n번째 줄, 1) 10-n개의 공백을 출력 그 다음 2) n개의 별을 출력
              *
             **
            ***
           ****
          *****
         ******
        *******
       ********
      *********
     **********
    */
    printf("for_05. 결과\n");
    int l,m,n;
    for (l=1; l<=10; l++) {
        for (m=1; m<=10-l; m++) { printf(" "); }
        for (n=1; n<=l; n++) { printf("*"); }
        printf("\n");
    }

    // 연습 6) for문과 조건문을 이용해 다음과 같이 출력해보자
    /*
         *
        ***
       *****
      *******
     *********
    */
    printf("for_06. 결과\n");
    int o,p,q;
    for (o=1; o<=10; o++) {
        if (o%2 == 1) {
            for (p=1; p<=(9-o)/2; p++) { printf(" "); }
            for (q=1; q<=o; q++) { printf("*"); }
            printf("\n");
        }
    }

    // 연습 7) for문과 조건문을 이용해 다음과 같이 출력해보자
    /*
     *********
      *******
       *****
        ***
         *
    */
    printf("for_07. 결과\n");
    int r,s,t;
    for (r=10; r>=1; r--) {
        if (r%2 == 1) {
            for (s=1; s<=(9-r)/2; s++) { printf(" "); }
            for (t=1; t<=r; t++) { printf("*"); }
            printf("\n");
        }
    }

    // 연습 8) 0부터 9까지 모두 더해서 출력해보자
    printf("for_08. 결과\n");
    int sum = 0;
    int u;
    for (u=0; u<10; u++) { sum += u; }
    printf("%d\n", sum);

    // 연습 9) 0부터 9까지 값들의 평균값은?
    printf("for_09. 결과\n");
    printf("%.1f\n", sum/10.0);

    // 연습 10) 숫자 v가 있을 때, 0~v 사이의 짝수들의 합은? (0~v은 0과 v도 포함이라 가정)
    printf("for_10~12. 숫자 v 입력하세요: ");
    int v;
    scanf("%d", &v);
    int w;
    int sum10 = 0;
    for (w=0; w<=v; w++) {
        if (w % 2 == 0) { sum10 += w; }
    }
    printf("ans_10: %d\n", sum10);

    // 연습 11) 숫자 n이 있을 때, 0부터 n까지의 합을 for문을 통해 구하는데 합계 값이 100을 넘으면 더하기 연산을 멈추고 100을 넘은 해당 값을 출력한다.
    int x;
    int sum11 = 0;
    for (x=0; x<=v; x++) {
        sum11 += x;
        if (sum11 > 100) { break; }
    }
    printf("ans_11: %d\n", sum11);

    // 연습 12) 숫자 n이 있을 때, 0부터 n까지의 합을 for문을 통해 구하는데 10의 배수인 값은 더하지 않는다.
    int y;
    int sum12 = 0;
    for (y=0; y<=v; y++) {
        if (y % 10 == 0) { continue; }
        sum12 += y;
    }
    printf("ans_12: %d\n", sum12);

    // 연습 13) 구구단을 출력해보자.
    printf("for_13. 결과\n");
    int aa, bb;
    for (aa=1; aa<10; aa++) {
        for (bb=1; bb<10; bb++) {
            printf("%d x %d = %d\n", aa, bb, aa*bb);
        }
    }

    // 연습 14) 1~100 사이 정수 중, 3의 배수와 5의 배수를 역순으로 출력시키는데 3과 5의 배수일 경우 "15"와 같이 ""를 통해 출력한다.
    // Ex) 100 99 96 95 93 "90" 87 ... 5 3
    // 문자열에서 쌍따옴표 "를 출력하고 싶을 땐, 백슬래쉬 \를 쌍따옴표 " 앞에 붙여 출력해줄 수 있다.
    // 10 "15" 20
    printf("for_14. 결과\n");
    int cc;
    for (cc=100; cc>0; cc--) {
        if ((cc%3 == 0) && (cc%5 == 0)) {
            printf("\"%d\" ", cc);
        }
        else if ((cc%3 == 0) || (cc%5 == 0)) {
            printf("%d ", cc);
        }
    }
    printf("\n");

    // 연습 15) 비밀번호 입력 시스템을 만들어보자. 사용자로부터 비밀번호를 입력받아 비밀번호가 맞으면 "PASS"를 출력하고 틀리면 "FAIL"을 출력하도록 하자. 단, 최대 5회까지 입력이 가능하도록 하고 마지막 입력에서 비밀번호가 틀리면 "You failed 5 tiems"를 출력하도록 하자. 편의상 비밀번호는 1000~9999 사이의 정수형 값이라 가정한다. for문 사용, 정답 비밀번호는 마음대로 설정
    printf("for_15. 결과\n");
    int dd;
    int anspwd=1111;
    for (dd=0; dd<5; dd++) {
        printf("비밀번호를 입력하세요(1000~9999): ");
        int pwd;
        scanf("%d", &pwd);
        if (pwd == anspwd) {
            printf("PASS\n");
            break;
        }
        else {
            if (dd != 4) { printf("FAIL\n"); }
            else { printf("You failed 5 times\n"); }
        }
    }




    // 반복문 while문을 연습해보자

    // 연습 1) 0부터 9까지 출력해보자
    int aaa=0;
    while (aaa < 10) {
        printf("%d ", aaa);
        aaa++;
    }
    printf("\n");

    // 연습 2 ~ 15) 위 for문 연습문제(2~12)들을 for문이 아닌 while문으로 실행해본다.
    
    // 연습 2) while문을 이용해 "****"을 총 10줄 출력해보자
    int bbb = 0;
    while (bbb < 10) {
        printf("****\n");
        bbb++;
    }
    
    // 연습 3) while문을 이용해 다음과 같이 출력해보자
    /*
     *
     **
     ***
     ****
     *****
     ******
     *******
     ********
     *********
     **********
    */
    int ccc = 1;
    while (ccc <= 10) {
        int ddd = 1;
        while (ddd <= ccc) {
            printf("*");
            ddd++;
        }
        ccc++;
        printf("\n");
    }

    // 연습 4) while문과 조건문을 이용해 다음과 같이 출력해보자
    /*
     *
     ***
     *****
     *******
     *********
    */
    int eee = 1;
    while (eee <= 10) {
        if (eee % 2 == 1) {
            int fff = 1;
            while (fff <= eee) {
                printf("*");
                fff++;
            }
            printf("\n");
        }
        eee++;
    }

    // 연습 5) while문을 이용해 다음과 같이 출력해보자
    /*
              *
             **
            ***
           ****
          *****
         ******
        *******
       ********
      *********
     **********
    */
    int ggg = 1;
    while (ggg <= 10) {
        int hhh = 1;
        while (hhh <= 10-ggg) {
            printf(" ");
            hhh++;
        }
        int iii = 1;
        while (iii <= ggg) {
            printf("*");
            iii++;
        }
        ggg++;
        printf("\n");
    }

    // 연습 6) while문과 조건문을 이용해 다음과 같이 출력해보자
    /*
         *
        ***
       *****
      *******
     *********
    */
    int jjj = 1;
    while (jjj <= 10) {
        if (jjj % 2 == 1) {
            int kkk = 1;
            while (kkk <= (9-jjj)/2) {
                printf(" ");
                kkk++;
            }
            int lll = 1;
            while (lll <= jjj) {
                printf("*");
                lll++;
            }
            printf("\n");
        }
        jjj++;
    }

    // 연습 7) while문과 조건문을 이용해 다음과 같이 출력해보자
    /*
     *********
      *******
       *****
        ***
         *
    */
    int mmm = 10;
    while (mmm >= 1) {
        if (mmm % 2 == 1) {
            int nnn = 1;
            while (nnn <= (9-mmm)/2) {
                printf(" ");
                nnn++;
            }
            int ooo = 1;
            while (ooo <= mmm) {
                printf("*");
                ooo++;
            }
            printf("\n");
        }
        mmm--;
    }

    // 연습 8) 0부터 9까지 모두 더해서 출력해보자
    int ppp;
    int sum8 = 0;
    for (ppp = 0; ppp<10; ppp++) {
        sum8 += ppp;
    }
    printf("%d\n", sum8);

    // 연습 9) 0부터 9까지 값들의 평균값은?
    int qqq;
    int sum9 = 0;
    for (qqq = 0; qqq<10; qqq++) {
        sum9 += qqq;
    }
    printf("%.3f\n", sum9/10.0);

    // 연습 10) 숫자 v가 있을 때, 0~v 사이의 짝수들의 합은? (0~v은 0과 v도 포함이라 가정)
    int ab;
    printf("숫자를 입력하세요: ");
    scanf("%d", &ab);
    int bc = 0;
    int cd = 0;
    while (bc <= ab) {
        if (bc % 2 == 0) {
            cd += bc;
        }
        bc++;
    }
    printf("%d\n", cd);

    // 연습 11) 숫자 n이 있을 때, 0부터 n까지의 합을 while문을 통해 구하는데 합계 값이 100을 넘으면 더하기 연산을 멈추고 100을 넘은 해당 값을 출력한다.
    int de;
    printf("숫자를 입력하세요: ");
    scanf("%d", &de);
    int ef = 0;
    int fg = 0;
    while (ef <= de) {
        fg += ef;
        if (fg > 100) { break; }
        ef++;
    }
    printf("%d\n", fg);

    // 연습 12) 숫자 n이 있을 때, 0부터 n까지의 합을 while문을 통해 구하는데 10의 배수인 값은 더하지 않는다.
    int abc;
    printf("숫자를 입력하세요: ");
    scanf("%d", &abc);
    int def = 0;
    int ghi = 0;
    while (def <= abc) {
        if (def % 10 != 0) {
            ghi += def;
        }
        def++;
    }
    printf("%d\n", ghi);

    // 연습 13) 구구단을 출력해보자.
    int gugur = 1;
    while (gugur < 10) {
        int guguc = 1;
        while (guguc < 10) {
            printf("%d * %d = %d\n", gugur, guguc, gugur*guguc);
            guguc++;
        }
        gugur++;
    }

    // 연습 14) 1~100 사이 정수 중, 3의 배수와 5의 배수를 역순으로 출력시키는데 3과 5의 배수일 경우 "15"와 같이 ""를 통해 출력한다.
    // Ex) 100 99 96 95 93 "90" 87 ... 5 3
    // 문자열에서 쌍따옴표 "를 출력하고 싶을 땐, 백슬래쉬 \를 쌍따옴표 " 앞에 붙여 출력해줄 수 있다.
    // 10 "15" 20
    int baesu = 100;
    while (baesu > 0) {
        if ((baesu % 5 == 0) && (baesu % 3 == 0)) {
            printf("\"%d\" ", baesu);
        } else if ((baesu % 5 == 0) || (baesu % 3 == 0)) {
            printf("%d ", baesu);
        }
        baesu--;
    }
    printf("\n");

    // 연습 15) 비밀번호 입력 시스템을 만들어보자. 사용자로부터 비밀번호를 입력받아 비밀번호가 맞으면 "PASS"를 출력하고 틀리면 "FAIL"을 출력하도록 하자. 단, 최대 5회까지 입력이 가능하도록 하고 마지막 입력에서 비밀번호가 틀리면 "You failed 5 tiems"를 출력하도록 하자. 편의상 비밀번호는 1000~9999 사이의 정수형 값이라 가정한다. 정답 비밀번호는 마음대로 설정
    int wanspwd = 1234;
    int trial = 0;
    while (trial < 5) {
        int wpwd;
        printf("비밀번호를 입력하세요: ");
        scanf("%d", &wpwd);
        if (wpwd == wanspwd) {
            printf("PASS\n");
            break;
        }
        else {
            if (trial == 4) {
                printf("You failed 5 times\n");
            } else {
                printf("FAIL\n");
            }
        }
        trial++;
    }

    // 연습 16) 정수형 변수 zigzag가 있다고 하자. 해당 변수의 값이 짝수면 5를 빼고 홀수면 1을 더하는 과정을 해당 변수의 값이 0보다 작아질 때까지 반복하다고 가정했을 때 변수의 초기값이 100이면 덧셈 및 뺄셈의 연산을 총 몇 번 수행할까?
    // Ex) 초기값이 5일 경우, 5 -> 6 -> 1 -> 2 -> -3 이므로 총 4번의 연산이 수행된다.
    int zigzag = 100;
    int zcount = 0;
    while (1) {
        if (zigzag % 2 == 0) { zigzag -= 5; }
        else { zigzag += 1; }
        zcount++;
        if (zigzag < 0) { break; }
    }
    printf("%d\n", zcount);
    
     
    return 0;
}

