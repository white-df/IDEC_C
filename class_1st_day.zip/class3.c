#include <stdio.h>
#include "myheader.h"
#include <math.h>

// 전역변수
int globalVariable = 10;
int count = 1;

// 매크로
#define PI 3.14

// 3차시. 함수

// 연습 1)
void ex1(void);

// 연습 2)
void ex2(int n) {
    int i;
    for (i=0; i<n; i++) {
        printf("Hello, World!\n");
    }
}

// 연습 3)
int ex3(int n) { return n; }

// 연습 4)
void ex4(int n) {
    if      (n % 2 == 0) { printf("EVEN\n"); }
    else if (n % 2 == 1) { printf("ODD\n"); }
}

// 연습 5)
void ex5(int num) {
    globalVariable += num;
}

// 연습 6)
int ex6(int num1, int num2) {
    int ans = 0;
    if      (num1 >= num2) { ans = num1; }
    else if (num2 > num1) { ans = num2; }
    return ans;
}

// 연습 7)
float ex7(int num1, int num2, int num3) {
    return (num1 + num2 + num3) / 3.0;
}

// 연습 8)
void ex8(int num) {
    int hour = num / 3600;
    int min = (num % 3600) / 60;
    int sec = (num % 3600) % 60;
    printf("[ %d : %d : %d ]\n", hour, min, sec);
}

// 연습 9)
float ex9(int r) {
    return PI*r*r;
}

// 연습 10)
void ex10(int num) {
    int i;
    for (i=2; i<num; i++) {
        if (num % i == 0) {
            printf("%d is not a prime number\n", num);
            break;
        }
    }
    printf("%d is a prime number\n", num);
}

// 연습 11)
double ex11(int num) {
    double ans = 1;
    int i;
    for (i=1; i<=num; i++) { ans *= i; }
    return ans;
}

int fibonacci(int num) {
    if (num == 1) {
        printf("%d. Fibonacci(1): 1\n", count);
        count ++;
        return 1;
    } else if (num == 2) {
        printf("%d. Fibonacci(2): 1\n", count);
        count ++;
        return 1;
    } else if (num < 1) {
        printf("The input number is too small!\n");
        return 0;
    } else {
        int answer = fibonacci(num-1) + fibonacci(num-2);
        printf("%d. Fibonacci(%d): %d\n", count, num, answer);
        count ++;
        return answer;
    }
}

// 아래 main 또한 함수를 의미한다
int main(int argc, const char * argv[]) {
    
    // 1. 함수를 실습해보자
    
    // 함수는 다음과 같은 형태를 가진다.
    /*
     
     DataType FunctionName(DataType1 Parameter1, DataType2 Parameter2, ...) {
        함수 내용
        return value;
     }
     
     */
    
    // 만약 특정값을 반환하는 함수가 아닌 단순 출력과 같은 함수일 경우, 함수의 DataType을 'void'로 지정하고 return을 생략한다.
    // 만약 매개변수가 없는 함수의 경우, 소괄호 () 안에 void를 입력해준다.
    // 함수 정의는 main 함수 바깥에서 이루어진다.
    
    // 함수를 연습해보자
    
    // 연습 1) "Hello, World!"를 출력하는 함수를 만들어보고 실행시켜 보자.
    ex1();
    
    // 연습 2) 숫자를 매개변수로 입력받아 해당된 숫자만큼 "Hello, World!"를 출력하는 함수를 만들어보고 실행시켜 보자.
    int a = 5;
    ex2(a);

    // 연습 3) 숫자를 매개변수로 입력받아 해당된 숫자를 그대로 반환하는 함수를 작성해보고 해당 함수를 통해 반환값을 출력해보자.
    int b = 5;
    printf("%d\n", ex3(b));

    // 연습 4) 숫자를 매개변수로 입력받아 해당된 숫자가 홀수일 경우 "EVEN"을 출력하고 짝수일 경우 "ODD"를 출력하는 함수를 만들어보고 실행시켜 보자.
    int c = 5;
    ex4(c);

    // 연습 5) 숫자를 매개변수로 입력받아 해당된 숫자를 전역변수에 더해 값을 업데이트하는 함수를 만들어보고 전역변수를 출력해보자.
    int d = 5;
    ex5(d);
    printf("Global Variable: %d\n", globalVariable);

    // 연습 6) 두 수를 매개변수로 입력받아 두 수 중 큰 값을 반환하는 함수를 만들어보고 반환값을 출력해보자.
    int e = 3;
    int f = 5;
    printf("%d\n", ex6(e, f));

    // 연습 7) 세 수를 매겨변수로 입력받아 평균값을 반환하는 함수를 만들어보고 반환값을 출력해보자.
    int g = 3;
    int h = 8;
    int i = 7;
    printf("%.2f\n", ex7(g,h,i));

    // 연습 8) 초를 매개변수로 입력받아 [시:분:초] 형태로 출력하는 함수를 만드러보고 실행시켜 보자.
    int j = 8000;
    ex8(j);

    // 연습 9) 반지름 값을 매개변수로 입력받아 원의 넓이 값을 반환하는 함수를 만들어보고 반환값을 출력해보자.
    int k = 5;
    printf("%.3f\n", ex9(k));

    // 연습 10) 숫자를 매개변수로 입력받아 해당 숫자가 소수(Prime Number)인지 아닌지 출력하는 함수를 만들어보고 실행시켜 보자.
    // 소수(Prime Number)는 1과 자기 자신으로만 나눠지는 수를 말한다.
    // 예를 들어, 6은 1,2,3,6으로 나누어지므로 소수가 아니다.
    // 그러나, 5는 1과 5로만 나누어지기 때문에 소수이다.
    int l = 17;
    ex10(l);

    // 연습 11) 숫자를 매개변수로 입력받아 해당 숫자의 팩토리얼 값을 반환하는 함수를 만들어보고 반환값을 출력해보자.
    // 팩토리얼 n! = 1 * 2 * 3 * ... * n
    // 예를 들어, 5! = 1 * 2 * 3 * 4 * 5 = 120
    // 30을 입력했을 때의 결과값은?
    int m = 30;
    printf("%.f\n", ex11(m));
    printf("%lu, %lu\n", sizeof(double), sizeof(long double));

    // 30! ~= 2.65 * 10^32








    // 2. 재귀 함수를 실습해보자

    // 연습 1) 수업 때 배웠던 피보나치 수를 직접 구현해보자
    printf("The answer: %d\n", fibonacci(5));

    // 연습 2) 재귀 함수를 이용해 팩토리얼을 직접 구현해보자










    // 3. C 표준 라이브러리에 있는 헤더 파일을 실습해보자

    // math.h라는 C 표준 라이브러리에 있는 헤더 파일을 include해서 사용해보자
    // #include <math.h>
    // math.h에 있는 함수 목록: https://ko.wikipedia.org/wiki/C_수식_함수

    // 연습 1) 숫자 5의 제곱근(루트)을 연산해보자.
    double t = 5;
    printf("%.2f\n", sqrt(t));

    // 연습 2) 2의 3승을 연산해보자.
    printf("%f\n", pow(2.2, 3.2));









    // 4. 사용자 정의 헤더 파일을 실습해보자

    // 지금까지 작성함 함수들을 "myheader.h"라는 파일을 만들어 작성해보자.
    // 만든 헤더 파일에서 임의의 함수를 불러와 실행시켜보자.
    temp();



    return 0;
    // main 함수 또한 함수이기 때문에 반환값이 존재하며
    // 항상 정수형이고 포르그램이 종료될 때, 프로그램 종료 문구와 함께 반환값이 출력된다.
    // 반환값을 바꿔보고 실행시켜보자

    // 보통 함수에서 return 값이 가지는 의미를 다루어보자.
    // 프로그램을 작성하다 보면 여러 예외처리가 있다.
    // 향후에 다루겠지만 정수를 입력해야 하는데 사용자가 문자열을 입력하거나
    // 예상과 다른 입력 형태나 메모리 부족 등 다양한 이유로 인해 프로그램은 오류가 발생할 수 있는데
    // 이러한 오류로 인해 프로그램 혹은 함수가 종료될 경우, 어떠한 사유로 포로그램이 종료됐는지 알 수 있도록
    // 반환값의 값을 오류 코드의 역할로써 사용하는 경우가 많다.

    // 그래서 간혹 보면 단순히 출력하는 함수임에도 불구하고 함수의 자료형이 void가 아닌 경우가 종종 있다
    // 이는 실제로 올바르게 실행되지 않으면 특정 값을 반환하는 그런 함수들이다.
}

void ex1(void) {
    printf("Hello, World!\n");
}
