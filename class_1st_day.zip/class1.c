// 기본적으로 프로그래밍 언어는 위에서 아래로 읽는다

#include <stdio.h>
// "stdio.h"라는 헤더 파일을 불러온다는 것을 의미 (향후 배우게 될 내용)

int main(int argc, const char * argv[]) {
// 메인 함수는 프로그램을 실행시켰을 때, 가장 먼저 실행되는 함수
// argc와 argv는 아직 몰라도 되는 내용
    
    /*
     1. 프로그래밍을 시작해보자
    */
    
    printf("Hello, World!\n");
    // 콘솔 창에 "Hello, World!"라는 문자열을 출력한다.
    // 문자열은 큰따옴표 "" 안에 내용을 작성한다.
    // 여기서 '\n'은 개행 문자로 줄바꿈을 의미한다.
    // 즉, "Hello, World!"가 출력된 뒤, 다음줄로 위치가 이동한다는 의미
    
    // 개행 문자가 없는 것과 비교해보자
    printf("Hello, World!");
    
    // 문자열을 다른 걸로 바꿔서 시도해보자
    printf("Type your own string in here!\n\n");

    // 이렇게 '//'을 넣으면 해당 행은 주석 처리가 된다.
    // 주석 처리가 되면 주석 내용은 코드에 어떠한 영향도 끼치지 않는다.
    // 단순히 코드 작성자와 코드를 읽는 사람들을 위해 사용됨
    // 목적1: 코드 작성자가 긴 코드를 작성하면서 혼란이 없도록 하기 위해
    // 목적2: 코드를 읽는 사람이 긴 코드를 읽으면서 혼란이 없도록 하기 위해
    // 목적3: 특정 함수는 변수 등이 무엇을 의미하는지 설명하기 위해
    // 등 매우 다양한 목적으로 주석이 이용된다.

    /*
     이렇게 행이 아닌 특정 블록에 주석을 작성하고자 하면 지금과 같이 작성하면 됨
    */








    /*
     2. 자료형을 연습해보자
    */

    int a = 5;
//    int a;
//    a = 5;
    // 정수형의 변수 'a'는 숫자 5라는 데이터를 담고 있다.

    float b = 1.2;
    // 실수형의 변수 'b'는 1.2라는 소수 형태의 데이터를 담고 있다.

    char c = 'k';
    // 문자형의 변수 'c'는 'k'라는 문자 형태의 데이터를 담고 있다.
    // 문자는 문자열과 다르게 작은 따옴표 '' 안에 문자를 작성한다.
    // 문자형 변수는 말그대로 문자 하나만 데이터로 담으며 이는 문자열과 다르고 더 작은 개념이다.
    // 작은 따옴표 안에 정수를 입력해도 이는 정수가 아닌 문자를 받아진다.
    // 단, '\n'과 같은 특수 문자는 백슬래쉬 '\'와 함께 나옴.
    // 특수 문자는 아스키 코드표를 참고
    // 문자형은 1byte짜리 데이터로 0~255까지의 값을 가지며 각 값은 특정 문자를 나타낸다.
    // 이는 아스키 코드표 참고
    // char c = 110;

    printf("You can print the integer data as follows: %d\n", 100);
    printf("You can print the integer data as follows: %d\n\n", a);
    // printf를 이용해 정수형 데이터를 출력할 땐
    // 위와 같이 문자열 내에 "%d"를 넣고 문자열 뒤에 출력하고자 하는 데이터를 입력한다
    // 이러한 방법을 formatting 포맷팅이라고 하며 %d와 같은 것을 형식지정자라고 한다

    printf("You can print the float data as follows: %f\n", 1.5);
    printf("You can print the float data as follows: %f\n\n", b);
    // printf를 이용해 실수형 데이터를 출력할 땐
    // 위와 같이 문자열 내에 "%f"를 넣고 문자열 뒤에 출력하고자 하는 데이터를 입력한다

    float t = 1.55456789;
    printf("You can print the float data as follows (f): %f\n", t);
    printf("You can print the float data as follows (.f): %.f\n", t);
    printf("You can print the float data as follows (.0f): %.0f\n", t);
    printf("You can print the float data as follows (.2f): %.2f\n", t);
    printf("You can print the float data as follows (.5f): %.5f\n\n", t);
    // printf를 이용해 실수형 데이터를 출력할 때, 소수점 아래로 원하는 자릿수만큼 출력하고 싶다면
    // 위와 같이 문자열 내에 "%.nf"를 넣으며 원하는 자릿수를 n이 있는 자리에 작성한다.
    // '%.f'는 '%.0f'와 동일하게 소수점 아래는 버리고 정수 부분만 출력한다.
    // '%f'는 '%.6f'와 동일하게 소수점 아래 여섯자리까지 출력한다.

    printf("You can print the character data as follows: %c\n", 'u');
    printf("You can print the character data as follows: %c\n", 120);
    printf("You can print the character data as follows: %c\n\n", c);
    // printf를 이용해 문자형 데이터를 출력할 땐
    // 위와 같이 문자열 내에 "%c"를 넣고 문자열 뒤에 출력하고자 하는 데이터를 입력한다
    // 아스키 코드 값으로도 출력 가능

    printf("You can print multiple data as follows: %d, %f, %c, %.2f\n\n", a, b, c, t);
    // printf를 이용해 여러 데이터를 출력할 땐
    // 동일하게 각 변수의 자료형에 맞게 %d, %f, %c 등을 문자열에 작성하지만
    // 콤마 뒤에 나오는 변수들의 순서가 문자열에서의 순서와 동일해야 한다.

    double d = 1.35;
    printf("You can print the double data as follows: %f\n\n", d);
    // 실수형의 변수 'd'는 1.35라는 소수 형태의 데이터를 담고 있다.
    // 형식지정자는 float과 동일하게 %f를 사용

    unsigned int e = 35;
    printf("You can print the unsigned integer data as follows: %u\n\n", e);
    // 부호가 없는 정수형 데이터를 다루고 싶을 경우, 정수형 자료형 앞에 unsigned를 추가적으로 작성한다.
    // unsigned만 작성하면 unsigned int로 받아들임
    // 형식지정자는 %u를 사용

    int f = 32147483647; // int가 최대로 담을 수 있는 값인 2,147,483,647을 초과했을 때
    printf("Answer: %d\n", f);
    // 범위를 넘어선 값이 입력되면 쓰레기값을 가지게 됨 (에러 발생!)
    // 큰 수를 다루게 될 경우, long을 사용

    long int g = 32147483647; // int가 최대로 담을 수 있는 값인 2,147,483,647을 초과했을 때
    printf("Answer: %ld\n\n", g);
    // 이 경우, int를 생략해도 상관이 없으며 정상적으로 값이 출력되는 것을 알 수 있다.
    // format은 %ld를 사용








    /*
     3. 기본 연산을 연습해보자
    */

    // 덧셈
    int add = a + 3;
    printf("The result of addition is %d\n", add);
    float add2 = a + 3;
    printf("The result of addition is %f\n", add2);
    float add3 = a + 3.0;
    printf("The result of addition is %f\n", add3);
    int add4 = a + 3.2;
    printf("The result of addition is %d\n\n", add4);
    // 정수형의 변수 'add'는 a + 3 이라는 더하기 연산의 결과값을 데이터로 담고 있다.
    // 연산하고자 하는 두 수가 같은 자료형일 경우, 연산의 결과는 해당 자료형으로 반환
    // 연산하고자 하는 두 수 중 하나가 실수형일 경우, 연산의 결과는 실수형으로 반환

    // 뺄셈
    int sub = a - 3;
    printf("The result of subtraction is %d\n", sub);
    float sub2 = a - 3;
    printf("The result of subtraction is %f\n", sub2);
    float sub3 = a - 3.2;
    printf("The result of subtraction is %f\n", sub3);
    int sub4 = a - 3.2;
    printf("The result of subtraction is %d\n\n", sub4);
    // 정수형의 변수 'sub'는 a - 3 이라는 빼기 연산의 결과값을 데이터로 담고 있다.
    // 연산하고자 하는 두 수가 같은 자료형일 경우, 연산의 결과는 해당 자료형으로 반환
    // 연산하고자 하는 두 수 중 하나가 실수형일 경우, 연산의 결과는 실수형으로 반환

    // 곱셈
    int mul = a * 3;
    printf("The result of multiplication is %d\n", mul);
    float mul2 = a * 3;
    printf("The result of multiplication is %f\n", mul2);
    float mul3 = a * 3.3;
    printf("The result of multiplication is %f\n", mul3);
    int mul4 = a * 3.3;
    printf("The result of multiplication is %d\n\n", mul4);
    // 정수형의 변수 'mul'은 a * 3 이라는 곱하기 연산의 결과값을 데이터로 담고 있다.
    // 연산하고자 하는 두 수가 같은 자료형일 경우, 연산의 결과는 해당 자료형으로 반환
    // 연산하고자 하는 두 수 중 하나가 실수형일 경우, 연산의 결과는 실수형으로 반환

    // 나눗셈
    int div = a / 3;
    printf("The result of division is %d\n", div);
    float div2 = a / 3;
    printf("The result of division is %f\n", div2);
    float div3 = a / 3.2;
    printf("The result of division is %f\n", div3);
    int div4 = a / 3.2;
    printf("The result of division is %d\n", div4);
    float div5 = 6.4 / 3.2;
    printf("The result of division is %f\n", div5);
    int div6 = 6.4 / 3.2;
    printf("The result of division is %d\n\n", div6);
    // 정수형의 변수 'div'는 a / 3 이라는 나누기 연산의 결과값을 데이터로 담고 있다.
    // 연산하고자 하는 두 수가 같은 자료형일 경우, 연산의 결과는 해당 자료형으로 반환
    // 연산하고자 하는 두 수 중 하나가 실수형일 경우, 연산의 결과는 실수형으로 반환

    // 나눗셈 - 나머지
    int rem = 10 % 3;
    printf("The remainder of division is %d\n\n", rem);
    // 정수형의 변수 'rem'는 10 / 3 이라는 나누기 연산의 나머지 값을 데이터로 담고 있으며
    // 이는 10 % 3 을 통해 계산된다.
    // 나머지 연산은 정수에서만 가능

    // 증감 연산자
    int h = 5;
    printf("%d\n", h);
    h++;
    printf("%d\n", h);
    h--;
    printf("%d\n\n", h);

    // 할당 연산자
    int i = 5;
    printf("%d\n", i);
    i += 3;
    printf("%d\n", i);
    i -= 5;
    printf("%d\n", i);
    i *= 2;
    printf("%d\n", i);
    i /= 2;
    printf("%d\n", i);
    i %= 2;
    printf("%d\n\n", i);
    
    

    return 0;
    // 항상 main 함수 마지막에는 return 코드가 반드시 있어야 한다
    // 뒤에 나오는 값을 어떤 것을 가져도 상관 없으나 정확히 무엇을 의미하는지는 향후 배울 예정
}

